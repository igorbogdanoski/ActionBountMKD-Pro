const fs = require('fs');
let content = fs.readFileSync('src/components/layout/Sidebar.tsx', 'utf-8');

const replacements = [
  [/bg-slate-950/g, 'dark:bg-slate-950 bg-slate-200'],
  [/border-slate-800/g, 'dark:border-slate-800 border-slate-300'],
  [/text-slate-400/g, 'dark:text-slate-400 text-slate-600'],
  [/text-slate-200/g, 'dark:text-slate-200 text-slate-900'],
  [/text-slate-300/g, 'dark:text-slate-300 text-slate-800'],
  [/bg-emerald-500\/10/g, 'dark:bg-emerald-500/10 bg-emerald-500/20'],
  [/text-emerald-400/g, 'dark:text-emerald-400 text-emerald-700'],
  [/text-white/g, 'dark:text-white text-black'],
];

replacements.forEach(([regex, replacement]) => {
  content = content.replace(regex, replacement);
});

fs.writeFileSync('src/components/layout/Sidebar.tsx', content);
