const fs = require('fs');
let content = fs.readFileSync('src/components/dashboard/BoundsDashboard.tsx', 'utf-8');

const replacements = [
  [/bg-slate-900/g, 'dark:bg-slate-900 bg-white'],
  [/bg-slate-800/g, 'dark:bg-slate-800 bg-slate-50'],
  [/bg-slate-950/g, 'dark:bg-slate-950 bg-slate-100'],
  [/text-slate-100/g, 'dark:text-slate-100 text-slate-900'],
  [/text-slate-200/g, 'dark:text-slate-200 text-slate-800'],
  [/text-slate-300/g, 'dark:text-slate-300 text-slate-700'],
  [/text-slate-400/g, 'dark:text-slate-400 text-slate-600'],
  [/border-slate-700/g, 'dark:border-slate-700 border-slate-200'],
  [/border-slate-800/g, 'dark:border-slate-800 border-slate-200'],
];

replacements.forEach(([regex, replacement]) => {
  content = content.replace(regex, replacement);
});

fs.writeFileSync('src/components/dashboard/BoundsDashboard.tsx', content);
