/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { BoundsDashboard } from './components/dashboard/BoundsDashboard';
import { BoundCreator } from './components/creator/BoundCreator';
import { CurrentView } from './components/layout/Sidebar';
import { MobilePlayer } from './components/player/MobilePlayer';
import { LandingPage } from './components/landing/LandingPage';
import { initMockData } from './utils/storage';

import { ResultsDashboard } from './components/dashboard/ResultsDashboard';
import { TemplatesLibrary } from './components/dashboard/TemplatesLibrary';

export type AppRoute = 'landing' | 'app';

export default function App() {
  const [appRoute, setAppRoute] = useState<AppRoute>('landing');
  const [currentView, setCurrentView] = useState<CurrentView>('dashboard');
  const [isPlayerView, setIsPlayerView] = useState(false);
  const [questId, setQuestId] = useState<string | null>(null);

  useEffect(() => {
    initMockData(); // Ensure mock data exists
    const path = window.location.pathname;
    if (path.startsWith('/play/')) {
      const id = path.split('/')[2];
      setQuestId(id);
      setIsPlayerView(true);
    }
  }, []);

  if (isPlayerView && questId) {
    return <MobilePlayer questId={questId} />;
  }

  if (appRoute === 'landing') {
    return (
      <LandingPage 
        onNavigateToCreator={() => {
          setAppRoute('app');
          setCurrentView('dashboard');
        }}
        onNavigateToPlayerDemo={() => {
          // Fallback demo for the mobile player if clicked from the landing page
          window.location.href = '/play/demo-quest-123';
        }}
      />
    );
  }

  return (
    <DashboardLayout currentView={currentView} onNavigate={setCurrentView}>
      {currentView === 'dashboard' && <BoundsDashboard onCreateNew={() => setCurrentView('creator')} />}
      {currentView === 'creator' && <BoundCreator />}
      {currentView === 'templates' && <TemplatesLibrary onUseTemplate={() => setCurrentView('creator')} />}
      {currentView === 'results' && <ResultsDashboard />}
      {currentView === 'settings' && <div>Поставки се во изработка...</div>}
    </DashboardLayout>
  );
}
