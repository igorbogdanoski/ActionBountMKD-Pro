export type Visibility = 'public' | 'secret';
export type PlayMode = 'singleplayer' | 'multiplayer';
export type SequenceType = 'fixed' | 'random' | 'selectable';

export interface Collaborator {
  email: string;
  role: 'viewer' | 'editor';
}

export interface Quest {
  id: string;
  creatorId: string;
  collaborators?: Collaborator[];
  title: string;
  description: string;
  coverImage?: string;
  visibility: Visibility;
  playMode: PlayMode;
  sequence: SequenceType;
  mapStyle?: string;
  startCoordinates?: Coordinates;
  destinationCoordinates?: Coordinates;
  createdAt: string;
  updatedAt: string;
  stages: Stage[];
}

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export type StageType = 'INFO' | 'QUIZ' | 'MISSION' | 'FIND_SPOT' | 'SCAN_CODE' | 'SURVEY';

export interface BaseStage {
  id: string;
  type: StageType;
  title: string;
  description: string;
  order: number;
  points?: number; // Gamification points
  audioUrl?: string;
}

export interface InfoStage extends BaseStage {
  type: 'INFO';
  mediaUrl?: string; // Image or video URL
  mediaType?: 'image' | 'video' | 'none';
}

export interface QuizStage extends BaseStage {
  type: 'QUIZ';
  questionType: 'multiple_choice' | 'free_text' | 'estimate_number';
  options?: string[]; // For multiple choice
  correctAnswer: string | number; 
  timeLimitSeconds?: number;
}

export interface MissionStage extends BaseStage {
  type: 'MISSION';
  submissionType: 'photo' | 'video' | 'audio';
}

export interface FindSpotStage extends BaseStage {
  type: 'FIND_SPOT';
  targetCoordinates: Coordinates;
  radiusMeters: number; // How close they need to be
  mapIcon?: string;
}

export interface ScanCodeStage extends BaseStage {
  type: 'SCAN_CODE';
  targetQrPayload: string; // The text/ID the QR code should contain
}

export interface SurveyStage extends BaseStage {
  type: 'SURVEY';
  surveyQuestions: string[];
}

export type Stage = InfoStage | QuizStage | MissionStage | FindSpotStage | ScanCodeStage | SurveyStage;
