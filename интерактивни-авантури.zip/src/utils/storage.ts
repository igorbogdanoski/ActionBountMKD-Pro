import { Quest } from '../types';
import { db } from './firebase';
import { collection, doc, getDocs, getDoc, setDoc, deleteDoc } from 'firebase/firestore';

const COLLECTION_NAME = 'quests';

export async function getQuests(): Promise<Quest[]> {
  try {
    const querySnapshot = await getDocs(collection(db, COLLECTION_NAME));
    return querySnapshot.docs.map(doc => doc.data() as Quest);
  } catch (error) {
    console.error("Error getting quests:", error);
    return [];
  }
}

export async function getQuestById(id: string): Promise<Quest | undefined> {
  try {
    const docRef = doc(db, COLLECTION_NAME, id);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as Quest;
    }
  } catch (error) {
    console.error("Error getting quest:", error);
  }
  return undefined;
}

export async function saveQuest(quest: Quest) {
  try {
    const docRef = doc(db, COLLECTION_NAME, quest.id);
    await setDoc(docRef, {
      ...quest,
      updatedAt: new Date().toISOString(),
      createdAt: quest.createdAt || new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.error("Error saving quest:", error);
  }
}

export async function deleteQuest(id: string) {
  try {
    await deleteDoc(doc(db, COLLECTION_NAME, id));
  } catch (error) {
    console.error("Error deleting quest:", error);
  }
}

export async function saveQuestResult(result: any) {
  try {
    const docRef = doc(collection(db, 'quest_results'));
    await setDoc(docRef, { ...result, id: docRef.id });
  } catch (error) {
    console.error("Error saving result:", error);
  }
}

export async function submitQuestFeedback(questId: string, playerName: string, comment: string, points: number) {
  try {
    const docRef = doc(collection(db, 'quest_feedback'));
    await setDoc(docRef, {
      questId,
      playerName,
      comment,
      points,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error submitting feedback:", error);
  }
}

export async function getQuestResults(questId?: string) {
  try {
    const querySnapshot = await getDocs(collection(db, 'quest_results'));
    const results = querySnapshot.docs.map(doc => doc.data() as any);
    if (questId) {
      return results.filter(r => r.questId === questId);
    }
    return results;
  } catch (error) {
    console.error("Error getting results:", error);
    return [];
  }
}

export async function saveUserTheme(theme: string) {
  try {
    const docRef = doc(db, 'user_settings', 'user-1');
    await setDoc(docRef, { theme, updatedAt: new Date().toISOString() }, { merge: true });
  } catch (error) {
    console.error("Error saving theme:", error);
  }
}

export async function getUserTheme(): Promise<string> {
  try {
    const docRef = doc(db, 'user_settings', 'user-1');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data().theme;
    }
  } catch (error) {
    console.error("Error getting theme:", error);
  }
  return 'dark'; // default
}

export async function cacheQuestResources(quest: Quest) {
  try {
    if (!('caches' in window)) return;
    const cache = await caches.open(`actionbound-quest-${quest.id}`);
    
    // Extract media urls
    const urlsToCache: string[] = [];
    quest.stages.forEach((stage: any) => {
      if (stage.mediaUrl) urlsToCache.push(stage.mediaUrl);
      if (stage.audioUrl) urlsToCache.push(stage.audioUrl);
    });

    // Add everything unique
    const uniqueUrls = Array.from(new Set(urlsToCache)).filter(url => url.startsWith('http'));
    for (const url of uniqueUrls) {
      if (url.includes('youtube.com')) continue; // Skip youtube iframes
      try {
        await cache.add(url);
      } catch (e) {
        console.warn(`Failed to cache ${url}`, e);
      }
    }
  } catch (error) {
    console.error("Error caching resources:", error);
  }
}

export async function initMockData() {
  const quest = await getQuestById('demo-quest-123');
  if (!quest) {
    await saveQuest({
      id: 'demo-quest-123',
      creatorId: 'user-1',
      title: 'Демо Авантура: Стара Чаршија',
      description: 'Откријте ги тајните на Скопската чаршија во овој краток демо квест.',
      visibility: 'public',
      playMode: 'singleplayer',
      sequence: 'fixed',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      stages: [
        {
          id: '1',
          type: 'INFO',
          title: 'Добредојдовте во Старата Чаршија',
          description: 'Оваа авантура ќе ве одведе низ историјата. Подгответе се!',
          order: 0,
          points: 10
        } as any,
        {
          id: '2',
          type: 'FIND_SPOT',
          title: 'Најди го објектот',
          description: 'Упатете се кон Даут Пашин Амам. Користете ја мапата за навигација.',
          targetCoordinates: { latitude: 41.9981, longitude: 21.4254 },
          radiusMeters: 50,
          order: 1,
          points: 100
        } as any,
        {
          id: '3',
          type: 'SCAN_CODE',
          title: 'Скенирај го влезот',
          description: 'Пронајдете го QR кодот залепен пред влезот на Амамот (За демо: симулирајте скенирање).',
          targetQrPayload: 'daut-pashin-secret-123',
          order: 2,
          points: 75
        } as any,
      ]
    });
  }
}